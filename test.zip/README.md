# dotfiles

dotfiles for my machines